<template>
  <div class="about">
    <h1>About</h1>
  </div>
</template>

<style lang="scss" scoped>
h1 {
  color: var(--test-color);
}
</style>
