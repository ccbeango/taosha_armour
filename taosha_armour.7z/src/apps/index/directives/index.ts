import type { App } from 'vue'

/**
 * 注册全局指令
 */
export default function setupGlobalDirevtives(app: App) {
  // console.log('注册全局指令')
}
