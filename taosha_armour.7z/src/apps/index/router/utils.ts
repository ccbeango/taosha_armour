export function t(str: string) {
  return str
}
