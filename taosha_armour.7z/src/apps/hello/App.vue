<script setup lang="ts"></script>

<template>
  <h2>Hello Page</h2>
  <router-view></router-view>
</template>
