export interface UserInfo {
  usreId: number
  username: string
  avatar: string
  desc?: string
  homePath?: string
  roles: string[]
}
